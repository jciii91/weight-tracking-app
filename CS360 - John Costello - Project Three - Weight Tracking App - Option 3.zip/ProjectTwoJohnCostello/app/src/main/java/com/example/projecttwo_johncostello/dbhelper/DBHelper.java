package com.example.projecttwo_johncostello.dbhelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "my_database";
    private static final int DATABASE_VERSION = 5;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create tables
        String createUsersTableQuery = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT, goal_weight DOUBLE)";
        String createWeightsTableQuery = "CREATE TABLE IF NOT EXISTS weights (id INTEGER PRIMARY KEY AUTOINCREMENT, weight DOUBLE, username TEXT)";
        db.execSQL(createUsersTableQuery);
        db.execSQL(createWeightsTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop tables when database is upgraded
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weights");
        onCreate(db);
    }

    public long insertData(String username, String password) {
        // inserts new user data
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        long id = db.insert("users", null, values);
        db.close();

        return id;
    }

    public boolean goodLogin(String username, String password) {
        // checks provided login credentials
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {"username", "password"};
        String[] selectionArgs = {username};
        Cursor cursor = db.query("users", columns, "username=?", selectionArgs, null, null, null);

        if (cursor.getCount() > 0) {
            cursor.moveToNext();
            int columnIndex = cursor.getColumnIndex("password");
            if (columnIndex != -1) {
                String stored_password = cursor.getString(columnIndex);
                return stored_password.equals(password);
            }
        }

        return false;
    }

    public double getGoal(String username) {
        // return goal weight
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {"username", "goal_weight"};
        String[] selectionArgs = {username};
        Cursor cursor = db.query("users", columns, "username=?", selectionArgs, null, null, null);

        if (cursor.getCount() > 0) {
            cursor.moveToNext();
            int columnIndex = cursor.getColumnIndex("goal_weight");
            if (columnIndex != -1) {
                return cursor.getDouble(columnIndex);
            }
        }

        return -1.0;
    }

    public void setGoal(String username, double newGoal) {
        // set goal weight
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("goal_weight", newGoal);

        // Update the goal_weight in the "users" table for the specified user
        db.update("users", values, "username=?", new String[]{username});

        // Close the database
        db.close();
    }

    public int insertWeight(double newWeight, String username) {
        // insert new measurement
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("weight", newWeight);
        values.put("username", username);
        int id = (int)db.insert("weights", null, values);
        db.close();

        return id;
    }

    public void deleteWeight(int id) {
        // delete measurement when row button is clicked
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("weights", "id=?", new String[]{String.valueOf(id)});
        db.close();
    }

    public Cursor getWeights(String username) {
        // get all stored weights when activity launches
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {"id", "weight"};
        String[] selectionArgs = {username};
        return db.query("weights", columns, "username=?", selectionArgs, null, null, null);
    }
}
