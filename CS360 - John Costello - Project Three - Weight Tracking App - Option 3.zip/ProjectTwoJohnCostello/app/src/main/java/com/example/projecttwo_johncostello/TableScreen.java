package com.example.projecttwo_johncostello;

import static java.lang.String.format;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.projecttwo_johncostello.dbhelper.DBHelper;

public class TableScreen extends AppCompatActivity implements View.OnClickListener {

    private DBHelper dbHelper;
    private String username;
    private Double goal;
    private boolean smsPermission;

    // Helper method to create a TextView with some common attributes
    private TextView createTextView(String text) {
        TextView textView = new TextView(this);
        textView.setLayoutParams(new TableRow.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        textView.setGravity(View.TEXT_ALIGNMENT_CENTER);
        textView.setPadding(8, 8, 8, 8);
        textView.setText(text);
        return textView;
    }

    // Helper method to create a Button with some common attributes
    private Button createButton(String text, int buttonId) {
        Button button = new Button(this);
        button.setLayoutParams(new TableRow.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        button.setPadding(8, 8, 8, 8);
        button.setText(text);
        button.setId(buttonId);
        button.setOnClickListener(this);
        return button;
    }

    // ran into issues with context when this was in the dialog screen code
    // moved it out to the activity class to resolve
    private TableRow createNewRow() {
        return new TableRow(this);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // set screen data based on main activity data passed in
        super.onCreate(savedInstanceState);
        setContentView(R.layout.information_grid);

        dbHelper = new DBHelper(this);
        username = getIntent().getStringExtra("username");
        smsPermission = getIntent().getBooleanExtra("smsPermission", false);

        goal = dbHelper.getGoal(username);

        // if there is a goal weight, set it on screen
        if (goal > 0.0) {
            TextView goal_textView = findViewById(R.id.goal_textView);
            @SuppressLint("DefaultLocale") String goalStr = format("%.2f", goal);
            goal_textView.setText(goalStr);
        }

        // if there are stored measurements populate the table
        Cursor storedWeights = dbHelper.getWeights(username);
        while(storedWeights.moveToNext()) {
            TableLayout tableLayout = findViewById(R.id.measurement_table);
            TableRow newRow = createNewRow();
            newRow.setLayoutParams(new TableRow.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));

            // Create a TextView for the cell displaying the double value
            TextView doubleCell = createTextView(String.valueOf(storedWeights.getDouble(1)));

            // Create a Button for the second cell
            Button buttonCell = createButton("Delete Entry", storedWeights.getInt(0));

            // Add the TextView and Button to the row
            newRow.addView(doubleCell);
            newRow.addView(buttonCell);

            // Add the new row to the TableLayout
            tableLayout.addView(newRow);
        }
    }

    @Override
    public void onClick(View view) {
        // onClick handler added for table row delete buttons
        int addBtn = findViewById(R.id.add_button).getId();
        int setBtn = findViewById(R.id.set_goal_button).getId();

        // if the button clicked was not Add or Set, it was a Delete button
        // Logout leaves the activity
        if (view.getId() != addBtn && view.getId() != setBtn) {
            dbHelper.deleteWeight(view.getId());

            TableLayout tableLayout = findViewById(R.id.measurement_table);
            Button clickedButton = findViewById(view.getId());
            tableLayout.removeView((TableRow)clickedButton.getParent());
        }
    }

    public void setGoal(View view) {
        // launch a dialog screen for entering the goal weight
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Goal Weight");

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_text_entry, null);
        builder.setView(dialogView);

        final EditText editText = dialogView.findViewById(R.id.set_goal_editText);

        // Set weight when OK is pressed
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Get the entered text
                String enteredText = editText.getText().toString();
                try {
                    double doubleValue = Double.parseDouble(enteredText);
                    dbHelper.setGoal(username, doubleValue);
                    goal = doubleValue;

                    TextView goal_textView = findViewById(R.id.goal_textView);
                    @SuppressLint("DefaultLocale") String goalStr = format("%.2f", doubleValue);
                    goal_textView.setText(goalStr);
                } catch (NumberFormatException e) {
                    return;
                }

                dialogInterface.dismiss();
            }
        });

        // Leave with no changes when Cancel is pressed
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        // Show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void addWeight(View view) {
        // launch dialog for adding measurements to the table
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Weight");

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_text_entry, null);
        builder.setView(dialogView);

        final EditText editText = dialogView.findViewById(R.id.set_goal_editText);

        // Log a measurement when the OK button is pressed
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Get the entered text
                String enteredText = editText.getText().toString();
                try {
                    double doubleValue = Double.parseDouble(enteredText);
                    int rowId = dbHelper.insertWeight(doubleValue, username);

                    TableLayout tableLayout = findViewById(R.id.measurement_table);
                    TableRow newRow = createNewRow();
                    newRow.setLayoutParams(new TableRow.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT));

                    // Create a TextView for the cell displaying the double value
                    TextView doubleCell = createTextView(String.valueOf(doubleValue));

                    // Create a Button for the second cell
                    // rowId is returned from the insert to the database, corresponds to the id in the weights table
                    Button buttonCell = createButton("Delete Entry", rowId);

                    // Add the TextView and Button to the row
                    newRow.addView(doubleCell);
                    newRow.addView(buttonCell);

                    // Add the new row to the TableLayout
                    tableLayout.addView(newRow);

                    if (smsPermission && doubleValue <= goal) {
                        // if the user gave permission for SMS messages
                        // and if the measurement entered is equal to or less than the goal
                        // send a message
                        String phoneNumber = "1234567890";
                        String message = "Congratulations! You have hit your goal weight!";

                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                    }
                } catch (NumberFormatException e) {
                    return;
                }

                dialogInterface.dismiss();
            }
        });

        // If Cancel is clicked then leave without doing anything
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        // Show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void logoutClicked(View view) {
        // return to the main screen when Logout is clicked
        Intent intent = new Intent(TableScreen.this, MainActivity.class);

        startActivity(intent);
    }
}
