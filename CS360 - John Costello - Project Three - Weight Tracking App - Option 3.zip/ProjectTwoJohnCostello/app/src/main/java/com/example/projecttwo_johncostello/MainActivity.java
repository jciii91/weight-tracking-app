package com.example.projecttwo_johncostello;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.projecttwo_johncostello.dbhelper.DBHelper;

public class MainActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private String _username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);
    }

    public void onSignupClicked(View view) {
        // try to create a new user
        EditText username_box = findViewById(R.id.editTextText);
        EditText password_box = findViewById(R.id.editTextText2);

        long id = dbHelper.insertData(username_box.getText().toString(), password_box.getText().toString());

        // if username is unique move to table screen
        // else display error message
        if (id > -1) {
            launchTableActivity(username_box.getText().toString());
        } else {
            TextView loginMessage = findViewById(R.id.login_message);
            loginMessage.setText(R.string.username_already_exists);
        }
    }

    public void onLoginClicked(View view) {
        // validate provided login credentials
        EditText username_box = findViewById(R.id.editTextText);
        String username = username_box.getText().toString();

        EditText password_box = findViewById(R.id.editTextText2);
        TextView loginMessage = findViewById(R.id.login_message);

        // go to table screen if valid
        // show error if not
        if (dbHelper.goodLogin(username, password_box.getText().toString())) {
            launchTableActivity(username);
        }
        else {
            loginMessage.setText(R.string.bad_credentials_message);
        }
    }

    public void launchTableActivity(String username) {
        // check if SMS permissions have been granted
        // if not, get user decision
        // if already granted, move to table screen
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {

            // Permission is not granted, request it from the user
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SEND_SMS}, 1);
            _username = username;
        } else {
            Intent intent = new Intent(MainActivity.this, TableScreen.class);
            intent.putExtra("username", username);
            intent.putExtra("smsPermission", true);

            startActivity(intent);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        // get user permission decision
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Intent intent = new Intent(MainActivity.this, TableScreen.class);

        // go to table activity screen either way, set permissions based on response or default to false if there was an issue
        if (requestCode == 1) {
            intent.putExtra("username", _username);
            intent.putExtra("smsPermission", grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED);
            startActivity(intent);
        } else {
            intent.putExtra("username", _username);
            intent.putExtra("smsPermission", false);
            startActivity(intent);
        }
    }
}